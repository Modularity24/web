// Slider //////////////////////////////////////////////////////////////////////////////////////////////////////////////

//- Superslider
//-$(function() {
//-    $('#slides').superslides({
//-        animation: 'fade',
//-        hashchange: false,
//-        pagination: true,
//-        play: 5000 // change to false to stop animation
//-    });
//-});

//- Responsive Slides
$(function() {
    $(".rslides").responsiveSlides({
        auto: true,             // Boolean: Animate automatically, true or false
        speed: 500,             // Integer: Speed of the transition, in milliseconds
        timeout: 4000,          // Integer: Time between slide transitions, in milliseconds
        pager: true,            // Boolean: Show pager, true or false
        nav: false,             // Boolean: Show navigation, true or false
        random: false,          // Boolean: Randomize the order of the slides, true or false
        pause: false,           // Boolean: Pause on hover, true or false
        pauseControls: true,    // Boolean: Pause when hovering controls, true or false
        prevText: "Previous",   // String: Text for the "previous" button
        nextText: "Next",       // String: Text for the "next" button
        maxwidth: "",           // Integer: Max-width of the slideshow, in pixels
        navContainer: "",       // Selector: Where controls should be appended to, default is after the 'ul'
        manualControls: "",     // Selector: Declare custom pager navigation
        namespace: "rslides",   // String: Change the default namespace used
        before: function(){},   // Function: Before callback
        after: function(){}     // Function: After callback
    });
});


// Fitvids /////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function () {
    $(".media-embed").fitVids();
});



// Widget: Flickr //////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $('#flickr').flickrfeed('27647038@N00', {                           // Your Flickr User ID
        limit: 1,                                                       // Thumbnails quantity
        imagesize: 'Large Square'                                       // Thumbnail size
    });
});



// Widget: Instagram ///////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function() {
    $("#instagram").jqinstapics({
        "user_id": "369",                                                  // Your Instagram User ID
        "access_token": "369.8567060.0e4d52144cd640a090ee08136d54b069",    // Your Instagram Access Token
        "count": 1,                                                        // Thumbnails quantity
        "size": "standard_resolution"                                      // Thumbnail size
    });
});



// Widget: Dribbble ////////////////////////////////////////////////////////////////////////////////////////////////////

$.jribbble.setToken('e1b2b748c02ef1fdd3cf942782b54bfb687faa01a7a351cef32deb9f98170d8e');
$.jribbble.users('davidappleyard').shots({per_page: 1}).then(function(shots) {
    var html = [];
    shots.forEach(function(shot) {
        html.push('<a href="' + shot.html_url + '" target="_blank" class="thumb solo-thumb">');
        html.push('<img src="' + shot.images.normal + '" >');
        html.push('</a>');
    });
    $('#dribbble-shots').html(html.join(''));
});




// Masonry + Infinite Scroll ///////////////////////////////////////////////////////////////////////////////////////////

$(function(){

    var $container = $('.grid');

    $container.imagesLoaded(function(){
        $container.masonry({
            itemSelector: '.grid-item',
            columnWidth: 350,
            gutter: 30
        });
    });

    $container.infinitescroll({
            navSelector  : '.site-pagination',    // selector for the paged navigation
            nextSelector : '.site-pagination a.pagination-next',  // selector for the NEXT link (to page 2)
            itemSelector : '.grid-item',     // selector for all items you'll retrieve
            loading: {
                finishedMsg: 'No more pages to load.',
                img: '../img/ajax-loader.gif'
            }
        },
        // trigger Masonry as a callback
        function( newElements ) {
            // hide new items while they are loading
            var $newElems = $( newElements ).css({ opacity: 0 });
            // ensure that images load before adding to masonry layout
            $newElems.imagesLoaded(function(){
                // show elems now they're ready
                $newElems.animate({ opacity: 1 });
                $container.masonry( 'appended', $newElems, true );
            });
        }
    );

});
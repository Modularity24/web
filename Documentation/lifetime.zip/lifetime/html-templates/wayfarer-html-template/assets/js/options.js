// Slider //////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(function() {
    $('#slides').superslides({
        animation: 'fade',
        hashchange: false,
        pagination: true,
        play: 5000 // change to false to stop animation
    });
});





// Fitvids /////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function () {
    $(".media-embed").fitVids();
});



// Widget: Flickr //////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $('#flickr').flickrfeed('27647038@N00', {                           // Your Flickr User ID
        limit: 4,                                                       // Thumbnails quantity
        imagesize: 'medium',                                            // Thumbnail size
        class: 'widget-thumb muted-hover-frame'                         // Thumbnail class
    });
});



// Widget: Instagram ///////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function() {
    $(".instagram").jqinstapics({
        "user_id": "369",                                                  // Your Instagram User ID
        "access_token": "369.8567060.0e4d52144cd640a090ee08136d54b069",    // Your Instagram Access Token
        "count": 10,                                                       // Thumbnails quantity
        "size": "standard_resolution",                                     // Thumbnail size
        "class": "widget-thumb muted-hover-frame"                          // Thumbnail class
    });
});



// Widget: Dribbble ////////////////////////////////////////////////////////////////////////////////////////////////////

$.jribbble.setToken('e1b2b748c02ef1fdd3cf942782b54bfb687faa01a7a351cef32deb9f98170d8e');
$.jribbble.users('misspato').shots({per_page: 4}).then(function(shots) {                    // Your Dribbble Username
    var html = [];
    shots.forEach(function(shot) {
        html.push('<a href="' + shot.html_url + '" target="_blank">');
        html.push('<img src="' + shot.images.normal + '" class="widget-thumb muted-hover-frame">');
        html.push('</a>');
    });
    $('#dribbble-shots').html(html.join(''));
});



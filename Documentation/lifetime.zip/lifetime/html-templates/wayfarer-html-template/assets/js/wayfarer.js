///////////////////////////////////////////////////////////////////////////////////////////////////


$(document).ready(function () {

    var body = $('#top');
    var pathArray = window.location.pathname.split('/');

    if (pathArray[1] === 'tagged' ||
        pathArray[1] === 'page' ||
        pathArray[1] === 'search' ||
        pathArray[1] === 'day') {
        //- is not home
        $(body).removeClass('is-home').addClass('is-nothome');
    }

    //- remove all home elements when not home
    $( ".is-nothome .hp-only" ).remove();
});


///////////////////////////////////////////////////////////////////////////////////////////////////


$(document).ready(function(){

    var toggle_button = $(".js-menu-toggle");

    // Menu Toggle
    $(toggle_button).click( function() {
        $("#menu").toggle();
        $(".menu-toggle-open").toggle();
    });

});


///////////////////////////////////////////////////////////////////////////////////////////////////


$(document).ready(function(){

    // Back to top
    var button = $(".back-top");

    $(button).hide(); // - hide #back-top first
    $(function () { // - fade in #back-top
        $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
                $(button).fadeIn();
            } else {
                $(button).fadeOut();
            }
        });
        $(button).click(function () { // - scroll body to 0px on click
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    });

});


///////////////////////////////////////////////////////////////////////////////////////////////////


$(document).ready(function(){
    $('.totalpages-count em').text('/');
});

///////////////////////////////////////////////////////////////////////////////////////////////////
//- adds a class if an image (.post-photo) is smaller than its container

$(document).ready(function(){
    $('img.post-photo').each(function(){
        var img_width = $(this).attr('width');
        var container_width = $(this).closest('.wrapper-photo').width();
        if ( img_width < container_width ) {
            $(this).addClass('narrow-photo');
        }
    });
});


///////////////////////////////////////////////////////////////////////////////////////////////////
//- Bootstrap Dropdown

/**
 * @preserve
 * ========================================================================
 * Bootstrap: dropdown.js v3.3.7
 * http://getbootstrap.com/javascript/#dropdowns
 * ========================================================================
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+function ($) {
    'use strict';

    // DROPDOWN CLASS DEFINITION
    // =========================

    var backdrop = '.dropdown-backdrop'
    var toggle   = '[data-toggle="dropdown"]'
    var Dropdown = function (element) {
        $(element).on('click.bs.dropdown', this.toggle)
    }

    Dropdown.VERSION = '3.3.7'

    function getParent($this) {
        var selector = $this.attr('data-target')

        if (!selector) {
            selector = $this.attr('href')
            selector = selector && /#[A-Za-z]/.test(selector) && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
        }

        var $parent = selector && $(selector)

        return $parent && $parent.length ? $parent : $this.parent()
    }

    function clearMenus(e) {
        if (e && e.which === 3) return
        $(backdrop).remove()
        $(toggle).each(function () {
            var $this         = $(this)
            var $parent       = getParent($this)
            var relatedTarget = { relatedTarget: this }

            if (!$parent.hasClass('open')) return

            if (e && e.type == 'click' && /input|textarea/i.test(e.target.tagName) && $.contains($parent[0], e.target)) return

            $parent.trigger(e = $.Event('hide.bs.dropdown', relatedTarget))

            if (e.isDefaultPrevented()) return

            $this.attr('aria-expanded', 'false')
            $parent.removeClass('open').trigger($.Event('hidden.bs.dropdown', relatedTarget))
        })
    }

    Dropdown.prototype.toggle = function (e) {
        var $this = $(this)

        if ($this.is('.disabled, :disabled')) return

        var $parent  = getParent($this)
        var isActive = $parent.hasClass('open')

        clearMenus()

        if (!isActive) {
            if ('ontouchstart' in document.documentElement && !$parent.closest('.navbar-nav').length) {
                // if mobile we use a backdrop because click events don't delegate
                $(document.createElement('div'))
                    .addClass('dropdown-backdrop')
                    .insertAfter($(this))
                    .on('click', clearMenus)
            }

            var relatedTarget = { relatedTarget: this }
            $parent.trigger(e = $.Event('show.bs.dropdown', relatedTarget))

            if (e.isDefaultPrevented()) return

            $this
                .trigger('focus')
                .attr('aria-expanded', 'true')

            $parent
                .toggleClass('open')
                .trigger($.Event('shown.bs.dropdown', relatedTarget))
        }

        return false
    }

    Dropdown.prototype.keydown = function (e) {
        if (!/(38|40|27|32)/.test(e.which) || /input|textarea/i.test(e.target.tagName)) return

        var $this = $(this)

        e.preventDefault()
        e.stopPropagation()

        if ($this.is('.disabled, :disabled')) return

        var $parent  = getParent($this)
        var isActive = $parent.hasClass('open')

        if (!isActive && e.which != 27 || isActive && e.which == 27) {
            if (e.which == 27) $parent.find(toggle).trigger('focus')
            return $this.trigger('click')
        }

        var desc = ' li:not(.disabled):visible a'
        var $items = $parent.find('.dropdown-menu' + desc)

        if (!$items.length) return

        var index = $items.index(e.target)

        if (e.which == 38 && index > 0)                 index--         // up
        if (e.which == 40 && index < $items.length - 1) index++         // down
        if (!~index)                                    index = 0

        $items.eq(index).trigger('focus')
    }


    // DROPDOWN PLUGIN DEFINITION
    // ==========================

    function Plugin(option) {
        return this.each(function () {
            var $this = $(this)
            var data  = $this.data('bs.dropdown')

            if (!data) $this.data('bs.dropdown', (data = new Dropdown(this)))
            if (typeof option == 'string') data[option].call($this)
        })
    }

    var old = $.fn.dropdown

    $.fn.dropdown             = Plugin
    $.fn.dropdown.Constructor = Dropdown


    // DROPDOWN NO CONFLICT
    // ====================

    $.fn.dropdown.noConflict = function () {
        $.fn.dropdown = old
        return this
    }


    // APPLY TO STANDARD DROPDOWN ELEMENTS
    // ===================================

    $(document)
        .on('click.bs.dropdown.data-api', clearMenus)
        .on('click.bs.dropdown.data-api', '.dropdown form', function (e) { e.stopPropagation() })
        .on('click.bs.dropdown.data-api', toggle, Dropdown.prototype.toggle)
        .on('keydown.bs.dropdown.data-api', toggle, Dropdown.prototype.keydown)
        .on('keydown.bs.dropdown.data-api', '.dropdown-menu', Dropdown.prototype.keydown)

}(jQuery);



///////////////////////////////////////////////////////////////////////////////////////////////////
//- Slider - Superslides

/**
 * @preserve
 * Superslides - v0.6.2 - 2013-07-10
 * https://github.com/nicinabox/superslides
 * Copyright (c) 2013 Nic Aitch; Licensed MIT */
(function(i,t){var n,e="superslides";n=function(n,e){this.options=t.extend({play:!1,animation_speed:600,animation_easing:"swing",animation:"slide",inherit_width_from:i,inherit_height_from:i,pagination:!0,hashchange:!1,scrollable:!0,elements:{preserve:".preserve",nav:".slides-navigation",container:".slides-container",pagination:".slides-pagination"}},e);var s=this,o=t("<div>",{"class":"slides-control"}),a=1;this.$el=t(n),this.$container=this.$el.find(this.options.elements.container);var r=function(){return a=s._findMultiplier(),s.$el.on("click",s.options.elements.nav+" a",function(i){i.preventDefault(),s.stop(),t(this).hasClass("next")?s.animate("next",function(){s.start()}):s.animate("prev",function(){s.start()})}),t(document).on("keyup",function(i){37===i.keyCode&&s.animate("prev"),39===i.keyCode&&s.animate("next")}),t(i).on("resize",function(){setTimeout(function(){var i=s.$container.children();s.width=s._findWidth(),s.height=s._findHeight(),i.css({width:s.width,left:s.width}),s.css.containers(),s.css.images()},10)}),t(i).on("hashchange",function(){var i,t=s._parseHash();i=t&&!isNaN(t)?s._upcomingSlide(t-1):s._upcomingSlide(t),i>=0&&i!==s.current&&s.animate(i)}),s.pagination._events(),s.start(),s},h={containers:function(){s.init?(s.$el.css({height:s.height}),s.$control.css({width:s.width*a,left:-s.width}),s.$container.css({})):(t("body").css({margin:0}),s.$el.css({position:"relative",overflow:"hidden",width:"100%",height:s.height}),s.$control.css({position:"relative",transform:"translate3d(0)",height:"100%",width:s.width*a,left:-s.width}),s.$container.css({display:"none",margin:"0",padding:"0",listStyle:"none",position:"relative",height:"100%"})),1===s.size()&&s.$el.find(s.options.elements.nav).hide()},images:function(){var i=s.$container.find("img").not(s.options.elements.preserve);i.removeAttr("width").removeAttr("height").css({"-webkit-backface-visibility":"hidden","-ms-interpolation-mode":"bicubic",position:"absolute",left:"0",top:"0","z-index":"-1","max-width":"none"}),i.each(function(){var i=s.image._aspectRatio(this),n=this;if(t.data(this,"processed"))s.image._scale(n,i),s.image._center(n,i);else{var e=new Image;e.onload=function(){s.image._scale(n,i),s.image._center(n,i),t.data(n,"processed",!0)},e.src=this.src}})},children:function(){var i=s.$container.children();i.is("img")&&(i.each(function(){if(t(this).is("img")){t(this).wrap("<div>");var i=t(this).attr("id");t(this).removeAttr("id"),t(this).parent().attr("id",i)}}),i=s.$container.children()),s.init||i.css({display:"none",left:2*s.width}),i.css({position:"absolute",overflow:"hidden",height:"100%",width:s.width,top:0,zIndex:0})}},c={slide:function(i,t){var n=s.$container.children(),e=n.eq(i.upcoming_slide);e.css({left:i.upcoming_position,display:"block"}),s.$control.animate({left:i.offset},s.options.animation_speed,s.options.animation_easing,function(){s.size()>1&&(s.$control.css({left:-s.width}),n.eq(i.upcoming_slide).css({left:s.width,zIndex:2}),i.outgoing_slide>=0&&n.eq(i.outgoing_slide).css({left:s.width,display:"none",zIndex:0})),t()})},fade:function(i,t){var n=this,e=n.$container.children(),s=e.eq(i.outgoing_slide),o=e.eq(i.upcoming_slide);o.css({left:this.width,opacity:1,display:"block"}),i.outgoing_slide>=0?s.animate({opacity:0},n.options.animation_speed,n.options.animation_easing,function(){n.size()>1&&(e.eq(i.upcoming_slide).css({zIndex:2}),i.outgoing_slide>=0&&e.eq(i.outgoing_slide).css({opacity:1,display:"none",zIndex:0})),t()}):(o.css({zIndex:2}),t())}};c=t.extend(c,t.fn.superslides.fx);var d={_centerY:function(i){var n=t(i);n.css({top:(s.height-n.height())/2})},_centerX:function(i){var n=t(i);n.css({left:(s.width-n.width())/2})},_center:function(i){s.image._centerX(i),s.image._centerY(i)},_aspectRatio:function(i){if(!i.naturalHeight&&!i.naturalWidth){var t=new Image;t.src=i.src,i.naturalHeight=t.height,i.naturalWidth=t.width}return i.naturalHeight/i.naturalWidth},_scale:function(i,n){n=n||s.image._aspectRatio(i);var e=s.height/s.width,o=t(i);e>n?o.css({height:s.height,width:s.height/n}):o.css({height:s.width*n,width:s.width})}},l={_setCurrent:function(i){if(s.$pagination){var t=s.$pagination.children();t.removeClass("current"),t.eq(i).addClass("current")}},_addItem:function(i){var n=i+1,e=n,o=s.$container.children().eq(i),a=o.attr("id");a&&(e=a);var r=t("<a>",{href:"#"+e,text:e});r.appendTo(s.$pagination)},_setup:function(){if(s.options.pagination&&1!==s.size()){var i=t("<nav>",{"class":s.options.elements.pagination.replace(/^\./,"")});s.$pagination=i.appendTo(s.$el);for(var n=0;s.size()>n;n++)s.pagination._addItem(n)}},_events:function(){s.$el.on("click",s.options.elements.pagination+" a",function(i){i.preventDefault();var t=s._parseHash(this.hash),n=s._upcomingSlide(t-1);n!==s.current&&s.animate(n,function(){s.start()})})}};return this.css=h,this.image=d,this.pagination=l,this.fx=c,this.animation=this.fx[this.options.animation],this.$control=this.$container.wrap(o).parent(".slides-control"),s._findPositions(),s.width=s._findWidth(),s.height=s._findHeight(),this.css.children(),this.css.containers(),this.css.images(),this.pagination._setup(),r()},n.prototype={_findWidth:function(){return t(this.options.inherit_width_from).width()},_findHeight:function(){return t(this.options.inherit_height_from).height()},_findMultiplier:function(){return 1===this.size()?1:3},_upcomingSlide:function(i){if(/next/.test(i))return this._nextInDom();if(/prev/.test(i))return this._prevInDom();if(/\d/.test(i))return+i;if(i&&/\w/.test(i)){var t=this._findSlideById(i);return t>=0?t:0}return 0},_findSlideById:function(i){return this.$container.find("#"+i).index()},_findPositions:function(i,t){t=t||this,void 0===i&&(i=-1),t.current=i,t.next=t._nextInDom(),t.prev=t._prevInDom()},_nextInDom:function(){var i=this.current+1;return i===this.size()&&(i=0),i},_prevInDom:function(){var i=this.current-1;return 0>i&&(i=this.size()-1),i},_parseHash:function(t){return t=t||i.location.hash,t=t.replace(/^#/,""),t&&!isNaN(+t)&&(t=+t),t},size:function(){return this.$container.children().length},destroy:function(){return this.$el.removeData()},update:function(){this.css.children(),this.css.containers(),this.css.images(),this.pagination._addItem(this.size()),this._findPositions(this.current),this.$el.trigger("updated.slides")},stop:function(){clearInterval(this.play_id),delete this.play_id,this.$el.trigger("stopped.slides")},start:function(){var n=this;n.options.hashchange?t(i).trigger("hashchange"):this.animate(),this.options.play&&(this.play_id&&this.stop(),this.play_id=setInterval(function(){n.animate()},this.options.play)),this.$el.trigger("started.slides")},animate:function(t,n){var e=this,s={};if(!(this.animating||(this.animating=!0,void 0===t&&(t="next"),s.upcoming_slide=this._upcomingSlide(t),s.upcoming_slide>=this.size()))){if(s.outgoing_slide=this.current,s.upcoming_position=2*this.width,s.offset=-s.upcoming_position,("prev"===t||s.outgoing_slide>t)&&(s.upcoming_position=0,s.offset=0),e.size()>1&&e.pagination._setCurrent(s.upcoming_slide),e.options.hashchange){var o=s.upcoming_slide+1,a=e.$container.children(":eq("+s.upcoming_slide+")").attr("id");i.location.hash=a?a:o}e.$el.trigger("animating.slides",[s]),e.animation(s,function(){e._findPositions(s.upcoming_slide,e),"function"==typeof n&&n(),e.animating=!1,e.$el.trigger("animated.slides"),e.init||(e.$el.trigger("init.slides"),e.init=!0,e.$container.fadeIn("fast"))})}}},t.fn[e]=function(i,s){var o=[];return this.each(function(){var a,r,h;return a=t(this),r=a.data(e),h="object"==typeof i&&i,r||(o=a.data(e,r=new n(this,h))),"string"==typeof i&&(o=r[i],"function"==typeof o)?o=o.call(r,s):void 0}),o},t.fn[e].fx={}})(this,jQuery);


///////////////////////////////////////////////////////////////////////////////////////////////////
//- Instagram - jQinstapics

/**
 * @preserve
 * jQInstaPics
 * Created by: Abid Din - http://craftedpixelz.co.uk
 * Contributions made by: Kacey Coughlin = http://www.kaceycoughlin.com
 * Version: 1.1b
 * Copyright: Crafted Pixelz
 * License: MIT license
 * Updated: 19th August 2013
 * Changed by: Misspato / October 13, 2016
 */

(function ($) {
    $.fn.jqinstapics = function (options) {

        // Defaults
        var defaults = {
            "user_id": null,
            "access_token": null,
            "count": 10,
            "size": "thumbnail",
            "class": "widget-thumb"
        };

        var o = $.extend(defaults, options);

        return this.each(function () {

            // Vars
            var elem = $(this),
                url = "https://api.instagram.com/v1/users/" + o.user_id + "/media/recent?access_token=" + o.access_token + "&count=" + o.count + "&callback=?";

            // Get the images
            $.getJSON(url, function(data){
                $.each(data.data, function (i, val) {
                    var a = $("<a/>", {"href": val.link, "target": "_blank", "class": o.class}).appendTo(elem);

                    //Size
                    if (o.size == null) { // Check if filled out, if not, use default
                        var img = $("<img/>", {"src": val.images.thumbnail.url}).appendTo(a);
                    } else if (o.size == "low_resolution") {
                        var img = $("<img/>", {"src": val.images.low_resolution.url}).appendTo(a);
                    } else if (o.size == "standard_resolution") {
                        var img = $("<img/>", {"src": val.images.standard_resolution.url}).appendTo(a);
                    } else {
                        // Invalid entry, use default
                        var img = $("<img/>", {"src": val.images.thumbnail.url}).appendTo(a);
                    }

                    if (val.caption){
                        a.attr("title", val.caption.text);
                    }
                });
            });

            if(o.user_id == null || o.access_token == null){
                elem.append("<p>Please specify a User ID and Access Token, as outlined in the docs.</p>");
            }

        });
    };
})(jQuery);






///////////////////////////////////////////////////////////////////////////////////////////////////
//- Dribbble

/**
 * @preserve
 * Jribbble v2.0.4 | Thu Jun 4 01:49:29 2015 -0400
 * Copyright (c) 2015, Tyler Gaw me@tylergaw.com
 * Released under the ISC-LICENSE
 */
!function(e,t,r,s){"use strict";e.jribbble={};var n=null,o="https://api.dribbble.com/v1",i=["animated","attachments","debuts","playoffs","rebounds","teams"],u={token:"Jribbble: Missing Dribbble access token. Set one with $.jribbble.accessToken = YOUR_ACCESS_TOKEN. If you do not have an access token, you must register a new application at https://dribbble.com/account/applications/new",singular:function(e){return e.substr(0,e.length-1)},idRequired:function(e){return"Jribbble: You have to provide a "+this.singular(e)+' ID. ex: $.jribbble.%@("1234").'.replace(/%@/g,e)},subResource:function(e){return"Jribbble: You have to provide a "+this.singular(e)+' ID to get %@. ex: $.jribbble.%@("1234").%@()'.replace(/%@/g,e)},shotId:function(e){return"Jribbble: You have to provide a shot ID to get %@. ex: "+' $.jribbble.shots("1234").%@()'.replace(/%@/g,e)},commentLikes:'Jribbble: You have to provide a comment ID to get likes. ex:  $.jribbble.shots("1234").comments("456").likes()'},c=function(e,t){if(e&&"object"!=typeof e)return e;throw new Error(u.idRequired(t))},l=function(e){var t={};return e.forEach(function(e){t[e]=d.call(this,e)}.bind(this)),t},h=function(t){var r=e.param(t);return r?"?"+r:""},a=function(e){if(0!==e.length){var t=e[0],r=typeof t,s={};if("number"===r||"string"===r){var n=i.indexOf(t);n>-1?s.list=t:s.resource=t}else"object"===r&&(s=t);return s}},b=function(){var t=e.extend({},e.Deferred()),r=function(){return this.methods=[],this.response=null,this.flushed=!1,this.add=function(e){this.flushed?e(this.scope):this.methods.push(e)},this.flush=function(e){if(!this.flushed){for(this.scope=e,this.flushed=!0;this.methods[0];)this.methods.shift()(e);return e}},this};return t.queue=new r,t.url=o,t.get=function(){return n?(e.ajax({type:"GET",url:this.url,beforeSend:function(e){e.setRequestHeader("Authorization","Bearer "+n)},success:function(e){this.resolve(e)}.bind(this),error:function(e){this.reject(e)}.bind(this)}),this):(console.error(u.token),!1)},t},f=function(t){return function(r){return e.extend(this,b()),this.queue.add(function(e){e.url+="/"+t+"/"+r}),setTimeout(function(){this.queue.flush(this).get()}.bind(this)),this}},d=function(e){return function(t){return this.queue.add(function(r){r.url+="/"+e+"/"+h(t||{})}),this}};e.jribbble.shots=function(t,r){var s=a([].slice.call(arguments))||{},n=r||{},o=function(t){return function(r,s){var n=a([].slice.call(arguments))||{},o=s||{};return this.queue.add(function(r){if(!r.shotId)throw new Error(u.shotId(t));r.url+="/"+t+"/",n.resource&&(r.url+=n.resource,delete n.resource),r.url+=h(e.extend(n,o))}),this}},i=function(){return e.extend(this,b()),this.url+="/shots/",this.queue.add(function(t){s.resource&&(t.shotId=s.resource,t.url+=s.resource,delete s.resource),t.url+=h(e.extend(s,n))}),setTimeout(function(){this.queue.flush(this).get()}.bind(this)),this};return i.prototype.attachments=o("attachments"),i.prototype.buckets=o("buckets"),i.prototype.likes=o("likes"),i.prototype.projects=o("projects"),i.prototype.rebounds=o("rebounds"),i.prototype.comments=function(t,r){var s=a([].slice.call(arguments))||{},n=r||{};return this.queue.add(function(t){if(!t.shotId)throw new Error(u.shotId("comments"));t.url+="/comments/",s.resource&&(t.commentId=s.resource,t.url+=s.resource+"/",delete s.resource),t.url+=h(e.extend(s,n))}),this.likes=function(e){var t=e||{};return this.queue.add(function(e){if(!e.commentId)throw new Error(u.commentLikes);e.url+="likes/"+h(t)}),this},this},new i},e.jribbble.teams=function(e){var t="teams",r=c(e,t),s=f.call(this,t);return s.prototype=l.call(this,["members","shots"]),new s(r)},e.jribbble.users=function(e){var t="users",r=c(e,t),s=f.call(this,t);return s.prototype=l.call(this,["buckets","followers","following","likes","projects","shots","teams"]),s.prototype.isFollowing=function(e){return this.queue.add(function(t){t.url+="/following/"+e}),this},new s(r)},e.jribbble.buckets=function(e){var t="buckets",r=c(e,t),s=f.call(this,t);return s.prototype=l.call(this,["shots"]),new s(r)},e.jribbble.projects=function(e){var t="projects",r=c(e,t),s=f.call(this,t);return s.prototype=l.call(this,["shots"]),new s(r)},e.jribbble.setToken=function(e){return n=e,this}}(jQuery,window,document);


///////////////////////////////////////////////////////////////////////////////////////////////////
//- Flickr

/**
 * @preserve
 * Plugin: jquery.FlickrFeed
 * Version: 1.0.0
 * Changed: Patricia Carvalho - October 13, 2016
 *
 * Description: jQuery plugin for display of Flickr photo feeds
 **/

(function($){

    $.fn.flickrfeed = function(userid, useroptions) {

        // Set pluign defaults
        var defaults = {
            limit: 8,
            imagesize: 'medium',
            class: 'widget-thumb'
        };
        var options = $.extend(defaults, useroptions);

        // Functions
        return this.each(function(i, e) {

            // Define Flickr feed API address
            var api = 'https://api.flickr.com/services/feeds/photos_public.gne?lang=en-us&format=json&jsoncallback=?';
            if (userid != '') api += '&id=' + userid;

            // Send request
            $.getJSON(api, function(data){

                // Process the feeds
                _callback(e, data, options);
            });
        });
    };

    // Callback function to create HTML result
    var _callback = function(e, data, options) {
        if (!data) {
            return false;
        }
        var html = '';

        // Add body
        html += '<div class="thumbs">';

        var feeds = data.items;
        var count = feeds.length;
        if (count > options.limit) count = options.limit;

        // Add feeds
        for (var i=0; i<count; i++) {

            // Get individual feed
            var photo= feeds[i];
            var link = '<a href="'+ photo.link +'" class="' + options.class + '" title="'+ photo.title +' (View on Flickr)" target="_black">';

            // Select image size
            var src = photo.media.m;
            if (options.imagesize == 'square') src = src.replace('_m', '_s');
            if (options.imagesize == 'thumbnail') src = src.replace('_m', '_t');
            if (options.imagesize == 'medium') src = src.replace('_m', '');

            html += link +'<img src="'+ src + '" alt="'+ photo.title +'"></a>';

        }

        html += '</div>'

        $(e).html(html);
    };
})(jQuery);

///////////////////////////////////////////////////////////////////////////////////////////////////
//- Keyboard Navigation

/**
 * @preserve
 * mousetrap v1.6.0 craig.is/killing/mice */
!function(e,t,n){function r(e,t,n){return e.addEventListener?void e.addEventListener(t,n,!1):void e.attachEvent("on"+t,n)}function o(e){if("keypress"==e.type){var t=String.fromCharCode(e.which);return e.shiftKey||(t=t.toLowerCase()),t}return m[e.which]?m[e.which]:k[e.which]?k[e.which]:String.fromCharCode(e.which).toLowerCase()}function i(e,t){return e.sort().join(",")===t.sort().join(",")}function a(e){var t=[];return e.shiftKey&&t.push("shift"),e.altKey&&t.push("alt"),e.ctrlKey&&t.push("ctrl"),e.metaKey&&t.push("meta"),t}function c(e){return e.preventDefault?void e.preventDefault():void(e.returnValue=!1)}function u(e){return e.stopPropagation?void e.stopPropagation():void(e.cancelBubble=!0)}function l(e){return"shift"==e||"ctrl"==e||"alt"==e||"meta"==e}function s(){if(!v){v={};for(var e in m)e>95&&112>e||m.hasOwnProperty(e)&&(v[m[e]]=e)}return v}function f(e,t,n){return n||(n=s()[e]?"keydown":"keypress"),"keypress"==n&&t.length&&(n="keydown"),n}function p(e){return"+"===e?["+"]:(e=e.replace(/\+{2}/g,"+plus"),e.split("+"))}function d(e,t){var n,r,o,i=[];for(n=p(e),o=0;o<n.length;++o)r=n[o],b[r]&&(r=b[r]),t&&"keypress"!=t&&g[r]&&(r=g[r],i.push("shift")),l(r)&&i.push(r);return t=f(r,i,t),{key:r,modifiers:i,action:t}}function h(e,n){return null===e||e===t?!1:e===n?!0:h(e.parentNode,n)}function y(e){function n(e){e=e||{};var t,n=!1;for(t in b)e[t]?n=!0:b[t]=0;n||(K=!1)}function s(e,t,n,r,o,a){var c,u,s=[],f=n.type;if(!k._callbacks[e])return[];for("keyup"==f&&l(e)&&(t=[e]),c=0;c<k._callbacks[e].length;++c)if(u=k._callbacks[e][c],(r||!u.seq||b[u.seq]==u.level)&&f==u.action&&("keypress"==f&&!n.metaKey&&!n.ctrlKey||i(t,u.modifiers))){var p=!r&&u.combo==o,d=r&&u.seq==r&&u.level==a;(p||d)&&k._callbacks[e].splice(c,1),s.push(u)}return s}function f(e,t,n,r){k.stopCallback(t,t.target||t.srcElement,n,r)||e(t,n)===!1&&(c(t),u(t))}function p(e){"number"!=typeof e.which&&(e.which=e.keyCode);var t=o(e);if(t)return"keyup"==e.type&&w===t?void(w=!1):void k.handleKey(t,a(e),e)}function h(){clearTimeout(g),g=setTimeout(n,1e3)}function v(e,t,r,i){function a(t){return function(){K=t,++b[e],h()}}function c(t){f(r,t,e),"keyup"!==i&&(w=o(t)),setTimeout(n,10)}b[e]=0;for(var u=0;u<t.length;++u){var l=u+1===t.length,s=l?c:a(i||d(t[u+1]).action);m(t[u],s,i,e,u)}}function m(e,t,n,r,o){k._directMap[e+":"+n]=t,e=e.replace(/\s+/g," ");var i,a=e.split(" ");return a.length>1?void v(e,a,t,n):(i=d(e,n),k._callbacks[i.key]=k._callbacks[i.key]||[],s(i.key,i.modifiers,{type:i.action},r,e,o),void k._callbacks[i.key][r?"unshift":"push"]({callback:t,modifiers:i.modifiers,action:i.action,seq:r,level:o,combo:e}))}var k=this;if(e=e||t,!(k instanceof y))return new y(e);k.target=e,k._callbacks={},k._directMap={};var g,b={},w=!1,_=!1,K=!1;k._handleKey=function(e,t,r){var o,i=s(e,t,r),a={},c=0,u=!1;for(o=0;o<i.length;++o)i[o].seq&&(c=Math.max(c,i[o].level));for(o=0;o<i.length;++o)if(i[o].seq){if(i[o].level!=c)continue;u=!0,a[i[o].seq]=1,f(i[o].callback,r,i[o].combo,i[o].seq)}else u||f(i[o].callback,r,i[o].combo);var p="keypress"==r.type&&_;r.type!=K||l(e)||p||n(a),_=u&&"keydown"==r.type},k._bindMultiple=function(e,t,n){for(var r=0;r<e.length;++r)m(e[r],t,n)},r(e,"keypress",p),r(e,"keydown",p),r(e,"keyup",p)}if(e){for(var v,m={8:"backspace",9:"tab",13:"enter",16:"shift",17:"ctrl",18:"alt",20:"capslock",27:"esc",32:"space",33:"pageup",34:"pagedown",35:"end",36:"home",37:"left",38:"up",39:"right",40:"down",45:"ins",46:"del",91:"meta",93:"meta",224:"meta"},k={106:"*",107:"+",109:"-",110:".",111:"/",186:";",187:"=",188:",",189:"-",190:".",191:"/",192:"`",219:"[",220:"\\",221:"]",222:"'"},g={"~":"`","!":"1","@":"2","#":"3",$:"4","%":"5","^":"6","&":"7","*":"8","(":"9",")":"0",_:"-","+":"=",":":";",'"':"'","<":",",">":".","?":"/","|":"\\"},b={option:"alt",command:"meta","return":"enter",escape:"esc",plus:"+",mod:/Mac|iPod|iPhone|iPad/.test(navigator.platform)?"meta":"ctrl"},w=1;20>w;++w)m[111+w]="f"+w;for(w=0;9>=w;++w)m[w+96]=w.toString();y.prototype.bind=function(e,t,n){var r=this;return e=e instanceof Array?e:[e],r._bindMultiple.call(r,e,t,n),r},y.prototype.unbind=function(e,t){var n=this;return n.bind.call(n,e,function(){},t)},y.prototype.trigger=function(e,t){var n=this;return n._directMap[e+":"+t]&&n._directMap[e+":"+t]({},e),n},y.prototype.reset=function(){var e=this;return e._callbacks={},e._directMap={},e},y.prototype.stopCallback=function(e,t){var n=this;return(" "+t.className+" ").indexOf(" mousetrap ")>-1?!1:h(t,n.target)?!1:"INPUT"==t.tagName||"SELECT"==t.tagName||"TEXTAREA"==t.tagName||t.isContentEditable},y.prototype.handleKey=function(){var e=this;return e._handleKey.apply(e,arguments)},y.addKeycodes=function(e){for(var t in e)e.hasOwnProperty(t)&&(m[t]=e[t]);v=null},y.init=function(){var e=y(t);for(var n in e)"_"!==n.charAt(0)&&(y[n]=function(t){return function(){return e[t].apply(e,arguments)}}(n))},y.init(),e.Mousetrap=y,"undefined"!=typeof module&&module.exports&&(module.exports=y),"function"==typeof define&&define.amd&&define(function(){return y})}}("undefined"!=typeof window?window:null,"undefined"!=typeof window?document:null);

///////////////////////////////////////////////////////////////////////////////////////////////////
//- Fitvids

/**
 * @preserve
 * FitVids 1.1
 *
 * Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
 * Credit to Thierry Koblentz - http://www.alistapart.com/articles/creating-intrinsic-ratios-for-video/
 * Released under the WTFPL license - http://sam.zoy.org/wtfpl/
 *
 */

!function(t){"use strict";t.fn.fitVids=function(e){var i={customSelector:null,ignore:null};if(!document.getElementById("fit-vids-style")){var r=document.head||document.getElementsByTagName("head")[0],a=".fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}",d=document.createElement("div");d.innerHTML='<p>x</p><style id="fit-vids-style">'+a+"</style>",r.appendChild(d.childNodes[1])}return e&&t.extend(i,e),this.each(function(){var e=['iframe[src*="player.vimeo.com"]','iframe[src*="youtube.com"]','iframe[src*="youtube-nocookie.com"]','iframe[src*="kickstarter.com"][src*="video.html"]',"object","embed"];i.customSelector&&e.push(i.customSelector);var r=".fitvidsignore";i.ignore&&(r=r+", "+i.ignore);var a=t(this).find(e.join(","));a=a.not("object object"),a=a.not(r),a.each(function(e){var i=t(this);if(!(i.parents(r).length>0||"embed"===this.tagName.toLowerCase()&&i.parent("object").length||i.parent(".fluid-width-video-wrapper").length)){i.css("height")||i.css("width")||!isNaN(i.attr("height"))&&!isNaN(i.attr("width"))||(i.attr("height",9),i.attr("width",16));var a="object"===this.tagName.toLowerCase()||i.attr("height")&&!isNaN(parseInt(i.attr("height"),10))?parseInt(i.attr("height"),10):i.height(),d=isNaN(parseInt(i.attr("width"),10))?i.width():parseInt(i.attr("width"),10),o=a/d;if(!i.attr("id")){var h="fitvid"+e;i.attr("id",h)}i.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top",100*o+"%"),i.removeAttr("height").removeAttr("width")}})})}}(window.jQuery||window.Zepto);


///////////////////////////////////////////////////////////////////////////////////////////////////
//- Pseudo-preloader (last on page)

$(function () {
    $('body').css('opacity','1');
});
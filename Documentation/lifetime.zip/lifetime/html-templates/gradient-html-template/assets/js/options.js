//- verify which scripts to use
//- verify options per script
//- verify if hooks are ids or classes
//- remove unnecessary code


// Slider //////////////////////////////////////////////////////////////////////////////////////////////////////////////

//- Superslides
$(document).ready(function() {
    $('#slides').superslides({
        animation: 'slide',
        hashchange: false,
        pagination: false,
        navigation: true,
        play: 4000 // change to false to stop animation
    });
});




// Fitvids /////////////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function () {
    $(".media-embed").fitVids();
});



// Widget: Flickr //////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $('#flickr').flickrfeed('27647038@N00', {                           // Your Flickr User ID
        limit: 9,                                                       // Thumbnails quantity
        imagesize: 'medium',                                            // Thumbnail size
        class: 'widget-thumb'                                           // Thumbnail class
    });
});



// Widget: Instagram ///////////////////////////////////////////////////////////////////////////////////////////////////
$(document).ready(function() {
    $("#instagram").jqinstapics({
        "user_id": "369",
        "access_token": "369.8567060.0e4d52144cd640a090ee08136d54b069",
        "count": 9,
        "size": "thumbnail",
        "class": "widget-thumb"
    });
});



// Widget: Dribbble ////////////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $.jribbble.setToken('e1b2b748c02ef1fdd3cf942782b54bfb687faa01a7a351cef32deb9f98170d8e');
    $.jribbble.users('davidappleyard').shots({per_page: 9}).then(function (shots) {
        var html = [];
        shots.forEach(function (shot) {
            html.push('<a href="' + shot.html_url + '" target="_blank">');
            html.push('<img src="' + shot.images.normal + '" class="widget-thumb">');
            html.push('</a>');
        });
        $('#dribbble-shots').html(html.join(''));
    });
});

// Masonry + Infinite Scroll ///////////////////////////////////////////////////////////////////////////////////////////

function thumbResize( element ){

    jQuery(document).ready(function($) {

        $(window).resize(function () {

            var $size = $(element).width();

            $('.thumbtype-audio').each(function () {
                $(this).height($size);
            });

            $('iframe.soundcloud_audio_player').each(function () {
                $(this).height($size).width($size);
            });

            $('iframe.spotify_audio_player').each(function () {
                $(this).height($size).width($size);
            });

        }).resize();


    });

}

jQuery(document).ready(function($){

    thumbResize(".grid-sizer");

    var $container = $('.grid');

    $container.imagesLoaded(function(){
        $container.masonry({
            itemSelector: '.grid-item',
            columnWidth: '.grid-sizer',
            percentPosition: true,
            isResizable: true,
            gutter: 0
        });

    });

    $container.infinitescroll({
            navSelector  : '.site-pagination',    // selector for the paged navigation
            nextSelector : '.site-pagination a.pagination-next',  // selector for the NEXT link (to page 2)
            itemSelector : '.grid-item',     // selector for all items you'll retrieve
            loading: {
                finishedMsg: 'No more pages to load.',
                img: 'assets/img/ajax-loader.gif'
            }
        },

        // trigger Masonry as a callback
        function( newElements ) {
            // hide new items while they are loading
            var $newElems = $( newElements ).css({ opacity: 0 });
            // ensure that images load before adding to masonry layout
            $newElems.imagesLoaded(function(){
                // show elems now they're ready
                $newElems.animate({ opacity: 1 });
                thumbResize(".grid-sizer");
                $container.masonry( 'appended', $newElems, true );
            });
        }

    );

});




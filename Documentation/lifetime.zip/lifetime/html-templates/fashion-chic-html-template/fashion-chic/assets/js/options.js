// Slider //////////////////////////////////////////////////////////////////////////////////////////

$(function() {
    $(".rslides").responsiveSlides({
        auto: true,                     // Boolean: Animate automatically, true or false
        speed: 500,                     // Integer: Speed of the transition, in milliseconds
        timeout: 5000,                  // Integer: Time between slide transitions, in milliseconds
        pager: true,                    // Boolean: Show pager, true or false
        nav: false,                     // Boolean: Show navigation, true or false
        random: false,                  // Boolean: Randomize the order of the slides, true or false
        pause: false,                   // Boolean: Pause on hover, true or false
        pauseControls: true,            // Boolean: Pause when hovering controls, true or false
        prevText: "Previous",           // String: Text for the "previous" button
        nextText: "Next",               // String: Text for the "next" button
        maxwidth: "",                   // Integer: Max-width of the slideshow, in pixels
        navContainer: "",               // Selector: Where controls should be appended to, default is after the 'ul'
        manualControls: "",             // Selector: Declare custom pager navigation
        namespace: "rslides",           // String: Change the default namespace used
        before: function(){},           // Function: Before callback
        after: function(){}             // Function: After callback
    });
});


// Fitvids /////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $(".media-embed").fitVids();
});


// Flickr //////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
    $('#flickr').flickrfeed('27647038@N00', {                           // Your Flickr User ID
        limit: 9,                                                       // Thumbnails quantity
        imagesize: 'medium',                                            // Thumbnail size
        class: 'widget-thumb'                                           // Thumbnail class
    });
});


// Instagram ///////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
     $(".instagram").jqinstapics({             
         "user_id": "369",                                                  // Your Instagram User ID
         "access_token": "369.8567060.0e4d52144cd640a090ee08136d54b069",    // Your Instagram Access Token
         "count": 9,                                                        // Thumbnails quantity
         "size": "standard_resolution",                                     // Thumbnail size
         "class": "widget-thumb"                                            // Thumbnail class
     });
});


// Dribbble ////////////////////////////////////////////////////////////////////////////////////////


$.jribbble.setToken('e1b2b748c02ef1fdd3cf942782b54bfb687faa01a7a351cef32deb9f98170d8e');
$.jribbble.users('misspato').shots({per_page: 9}).then(function(shots) {                    // Your Dribbble Username
    var html = [];
    shots.forEach(function(shot) {
        html.push('<a href="' + shot.html_url + '" target="_blank">');
        html.push('<img src="' + shot.images.normal + '" class="widget-thumb">');
        html.push('</a>');
    });
    $('#dribbble-shots').html(html.join(''));
});
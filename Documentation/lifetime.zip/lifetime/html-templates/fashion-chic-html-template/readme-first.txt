

	Fashion Chic

	======================================================================================

	Thank you for buying this template!


	1. 	The Template is in the /fashion-chic folder

	2. 	The help file for the template is in the /documentation folder.

		You should read it before working with this product as it offers a very useful
		overview on it's folder structure, general page layout, plugin and script usage.

	3. 	If you need assistance with a problem and you don't find the solution in the
		documentation, just jump into our forums for help.

		Please send your message to our Forum:

		https://www.theme-junkie.com/forum/
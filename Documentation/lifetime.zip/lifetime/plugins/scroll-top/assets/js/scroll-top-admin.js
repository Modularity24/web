jQuery(document).ready(function($){
	/* Initialize color picker. */
	$('.color-scroll').wpColorPicker();
});